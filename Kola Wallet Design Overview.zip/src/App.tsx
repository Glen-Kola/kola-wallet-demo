import { useState } from 'react';
import { Home } from './components/Home';
import { Growth } from './components/Growth';
import { Security } from './components/Security';
import { Navigation } from './components/Navigation';
import { BiometricLogin } from './components/BiometricLogin';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<'home' | 'growth' | 'security'>('home');

  if (!isLoggedIn) {
    return <BiometricLogin onLogin={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      {/* Mobile Frame */}
      <div className="w-full max-w-[400px] h-[844px] bg-white rounded-[3rem] shadow-2xl overflow-hidden flex flex-col relative border-8 border-slate-900">
        {/* Status Bar */}
        <div className="bg-slate-900 text-white px-8 py-2 flex justify-between items-center text-xs">
          <span>9:41</span>
          <div className="flex gap-1 items-center">
            <div className="w-4 h-3 border border-white rounded-sm"></div>
            <div className="w-3 h-3 border border-white rounded-full"></div>
            <div className="w-4 h-3 bg-white rounded-sm"></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'home' && <Home />}
          {activeTab === 'growth' && <Growth />}
          {activeTab === 'security' && <Security />}
        </div>

        {/* Bottom Navigation */}
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  );
}