import { useState, useEffect } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-c5964f01`;
const USER_ID = 'demo-user';

interface Transaction {
  id: string;
  type: 'sent' | 'received' | 'recurring';
  recipient: string;
  amount: number;
  date: string;
  method: string;
  status: string;
}

interface SavingsGoal {
  id: string;
  name: string;
  target: number;
  current: number;
  color: string;
  createdAt: string;
}

interface Group {
  id: string;
  name: string;
  members: number;
  balance: number;
  nextPayout: string;
  createdAt: string;
}

interface Organization {
  id: string;
  name: string;
  role: string;
  balance: number;
  employees: number;
  pendingApprovals: number;
  createdAt: string;
}

async function apiFetch(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
      'X-User-Id': USER_ID,
      ...options.headers,
    },
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'API request failed');
  }

  return response.json();
}

export function useKolaWallet() {
  const [balance, setBalance] = useState<number>(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);

  // Initialize demo data on first load
  useEffect(() => {
    const initDemo = async () => {
      try {
        await apiFetch('/init-demo', { method: 'POST' });
      } catch (error) {
        console.error('Error initializing demo:', error);
      }
    };
    initDemo();
  }, []);

  // Fetch all data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [balanceRes, txRes, goalsRes, groupsRes, orgsRes] = await Promise.all([
        apiFetch('/balance'),
        apiFetch('/transactions'),
        apiFetch('/savings-goals'),
        apiFetch('/groups'),
        apiFetch('/organizations'),
      ]);

      setBalance(balanceRes.balance);
      setTransactions(txRes.transactions);
      setSavingsGoals(goalsRes.goals);
      setGroups(groupsRes.groups);
      setOrganizations(orgsRes.organizations);
    } catch (error) {
      console.error('Error fetching wallet data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Wait a bit for demo init
    setTimeout(fetchData, 500);
  }, []);

  // Create transaction
  const createTransaction = async (
    type: 'sent' | 'received',
    recipient: string,
    amount: number,
    method: string
  ) => {
    try {
      // Optimistic update
      const optimisticBalance = type === 'sent' 
        ? balance - amount - 0.50 
        : balance + amount;
      setBalance(optimisticBalance);

      const result = await apiFetch('/transaction', {
        method: 'POST',
        body: JSON.stringify({ type, recipient, amount, method }),
      });

      // Update with actual data
      setBalance(result.balance);
      await fetchData();

      return result;
    } catch (error) {
      console.error('Error creating transaction:', error);
      // Revert optimistic update
      await fetchData();
      throw error;
    }
  };

  // Create savings goal
  const createSavingsGoal = async (name: string, target: number, color: string) => {
    try {
      const result = await apiFetch('/savings-goal', {
        method: 'POST',
        body: JSON.stringify({ name, target, current: 0, color }),
      });

      await fetchData();
      return result;
    } catch (error) {
      console.error('Error creating savings goal:', error);
      throw error;
    }
  };

  // Update savings goal
  const updateSavingsGoal = async (id: string, updates: Partial<SavingsGoal>) => {
    try {
      const result = await apiFetch(`/savings-goal/${id}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
      });

      await fetchData();
      return result;
    } catch (error) {
      console.error('Error updating savings goal:', error);
      throw error;
    }
  };

  return {
    balance,
    transactions,
    savingsGoals,
    groups,
    organizations,
    loading,
    createTransaction,
    createSavingsGoal,
    updateSavingsGoal,
    refreshData: fetchData,
  };
}
