import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Initialize user data if not exists
async function initializeUser(userId: string) {
  const balance = await kv.get(`balance:${userId}`);
  if (!balance) {
    await kv.set(`balance:${userId}`, '2847.50');
  }
}

// Get user balance
app.get('/make-server-c5964f01/balance', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    await initializeUser(userId);
    
    const balance = await kv.get(`balance:${userId}`);
    return c.json({ balance: parseFloat(balance || '0') });
  } catch (error) {
    console.error('Error fetching balance:', error);
    return c.json({ error: 'Failed to fetch balance' }, 500);
  }
});

// Get transactions
app.get('/make-server-c5964f01/transactions', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const transactions = await kv.getByPrefix(`transaction:${userId}:`);
    
    const parsed = transactions
      .map(t => JSON.parse(t))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10);
    
    return c.json({ transactions: parsed });
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return c.json({ error: 'Failed to fetch transactions' }, 500);
  }
});

// Create transaction
app.post('/make-server-c5964f01/transaction', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const body = await c.req.json();
    const { type, recipient, amount, method } = body;

    if (!type || !recipient || !amount) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    // Get current balance
    const currentBalance = parseFloat(await kv.get(`balance:${userId}`) || '0');
    
    // Calculate new balance
    let newBalance = currentBalance;
    if (type === 'sent') {
      newBalance = currentBalance - parseFloat(amount) - 0.50; // Including fee
      if (newBalance < 0) {
        return c.json({ error: 'Insufficient balance' }, 400);
      }
    } else if (type === 'received') {
      newBalance = currentBalance + parseFloat(amount);
    }

    // Create transaction
    const transaction = {
      id: Date.now().toString(),
      type,
      recipient,
      amount: parseFloat(amount),
      method: method || 'MoMo',
      date: new Date().toISOString(),
      status: 'completed'
    };

    // Save transaction and update balance
    await kv.set(`transaction:${userId}:${transaction.id}`, JSON.stringify(transaction));
    await kv.set(`balance:${userId}`, newBalance.toString());

    return c.json({ 
      transaction,
      balance: newBalance,
      success: true 
    });
  } catch (error) {
    console.error('Error creating transaction:', error);
    return c.json({ error: 'Failed to create transaction' }, 500);
  }
});

// Get savings goals
app.get('/make-server-c5964f01/savings-goals', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const goals = await kv.getByPrefix(`goal:${userId}:`);
    
    const parsed = goals.map(g => JSON.parse(g));
    return c.json({ goals: parsed });
  } catch (error) {
    console.error('Error fetching savings goals:', error);
    return c.json({ error: 'Failed to fetch savings goals' }, 500);
  }
});

// Create savings goal
app.post('/make-server-c5964f01/savings-goal', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const body = await c.req.json();
    const { name, target, current, color } = body;

    if (!name || !target) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const goal = {
      id: Date.now().toString(),
      name,
      target: parseFloat(target),
      current: parseFloat(current || '0'),
      color: color || 'emerald',
      createdAt: new Date().toISOString()
    };

    await kv.set(`goal:${userId}:${goal.id}`, JSON.stringify(goal));

    return c.json({ goal, success: true });
  } catch (error) {
    console.error('Error creating savings goal:', error);
    return c.json({ error: 'Failed to create savings goal' }, 500);
  }
});

// Update savings goal
app.put('/make-server-c5964f01/savings-goal/:id', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const goalId = c.req.param('id');
    const body = await c.req.json();
    
    const goalKey = `goal:${userId}:${goalId}`;
    const existingGoal = await kv.get(goalKey);
    
    if (!existingGoal) {
      return c.json({ error: 'Goal not found' }, 404);
    }

    const goal = JSON.parse(existingGoal);
    const updatedGoal = { ...goal, ...body };
    
    await kv.set(goalKey, JSON.stringify(updatedGoal));

    return c.json({ goal: updatedGoal, success: true });
  } catch (error) {
    console.error('Error updating savings goal:', error);
    return c.json({ error: 'Failed to update savings goal' }, 500);
  }
});

// Get groups
app.get('/make-server-c5964f01/groups', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const groups = await kv.getByPrefix(`group:${userId}:`);
    
    const parsed = groups.map(g => JSON.parse(g));
    return c.json({ groups: parsed });
  } catch (error) {
    console.error('Error fetching groups:', error);
    return c.json({ error: 'Failed to fetch groups' }, 500);
  }
});

// Get organizations
app.get('/make-server-c5964f01/organizations', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    const orgs = await kv.getByPrefix(`org:${userId}:`);
    
    const parsed = orgs.map(o => JSON.parse(o));
    return c.json({ organizations: parsed });
  } catch (error) {
    console.error('Error fetching organizations:', error);
    return c.json({ error: 'Failed to fetch organizations' }, 500);
  }
});

// Initialize demo data
app.post('/make-server-c5964f01/init-demo', async (c) => {
  try {
    const userId = c.req.header('X-User-Id') || 'demo-user';
    
    // Set initial balance
    await kv.set(`balance:${userId}`, '2847.50');
    
    // Add demo transactions
    const demoTransactions = [
      {
        id: '1',
        type: 'sent',
        recipient: 'Sarah Johnson',
        amount: 45.00,
        date: new Date().toISOString(),
        method: 'MoMo',
        status: 'completed'
      },
      {
        id: '2',
        type: 'received',
        recipient: 'John Doe',
        amount: 120.50,
        date: new Date(Date.now() - 3600000).toISOString(),
        method: 'Bank Transfer',
        status: 'completed'
      },
      {
        id: '3',
        type: 'sent',
        recipient: 'Emma Wilson',
        amount: 67.20,
        date: new Date(Date.now() - 86400000).toISOString(),
        method: 'Orange Money',
        status: 'completed'
      }
    ];

    for (const tx of demoTransactions) {
      await kv.set(`transaction:${userId}:${tx.id}`, JSON.stringify(tx));
    }

    // Add demo savings goals
    const demoGoals = [
      {
        id: '1',
        name: 'Emergency Fund',
        target: 5000,
        current: 3200,
        color: 'emerald',
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Vacation 2026',
        target: 3000,
        current: 1450,
        color: 'blue',
        createdAt: new Date().toISOString()
      },
      {
        id: '3',
        name: 'New Laptop',
        target: 1500,
        current: 890,
        color: 'purple',
        createdAt: new Date().toISOString()
      }
    ];

    for (const goal of demoGoals) {
      await kv.set(`goal:${userId}:${goal.id}`, JSON.stringify(goal));
    }

    // Add demo groups
    const demoGroups = [
      {
        id: '1',
        name: 'Family Tontine',
        members: 8,
        balance: 12400,
        nextPayout: 'Dec 20',
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Friends Circle',
        members: 5,
        balance: 6750,
        nextPayout: 'Dec 28',
        createdAt: new Date().toISOString()
      }
    ];

    for (const group of demoGroups) {
      await kv.set(`group:${userId}:${group.id}`, JSON.stringify(group));
    }

    // Add demo organization
    const demoOrg = {
      id: '1',
      name: 'Acme Corp',
      role: 'Manager',
      balance: 45600,
      employees: 12,
      pendingApprovals: 3,
      createdAt: new Date().toISOString()
    };

    await kv.set(`org:${userId}:${demoOrg.id}`, JSON.stringify(demoOrg));

    return c.json({ success: true, message: 'Demo data initialized' });
  } catch (error) {
    console.error('Error initializing demo data:', error);
    return c.json({ error: 'Failed to initialize demo data' }, 500);
  }
});

Deno.serve(app.fetch);
