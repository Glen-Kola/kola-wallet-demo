import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface SmartCardProps {
  balance: number;
  loading?: boolean;
}

export function SmartCard({ balance, loading }: SmartCardProps) {
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);

  return (
    <div className="relative">
      {/* Main Card */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-6 shadow-lg">
        {/* Card Header */}
        <div className="flex justify-between items-start mb-12">
          <div>
            <p className="text-slate-400 text-sm mb-1">Total Balance</p>
            <div className="flex items-center gap-3">
              {loading ? (
                <div className="h-8 w-32 bg-slate-700 rounded animate-pulse"></div>
              ) : isBalanceVisible ? (
                <h2 className="text-white">${balance.toFixed(2)}</h2>
              ) : (
                <div className="flex gap-1">
                  <div className="w-3 h-3 bg-slate-600 rounded-full"></div>
                  <div className="w-3 h-3 bg-slate-600 rounded-full"></div>
                  <div className="w-3 h-3 bg-slate-600 rounded-full"></div>
                  <div className="w-3 h-3 bg-slate-600 rounded-full"></div>
                </div>
              )}
              <button
                onClick={() => setIsBalanceVisible(!isBalanceVisible)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                {isBalanceVisible ? (
                  <Eye className="w-5 h-5" />
                ) : (
                  <EyeOff className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
          <div className="bg-emerald-500 text-white text-xs px-3 py-1 rounded-full">
            Active
          </div>
        </div>

        {/* Card Footer */}
        <div className="flex justify-between items-end">
          <div>
            <p className="text-slate-400 text-xs mb-1">Card Number</p>
            <p className="text-white text-sm">•••• •••• •••• 4829</p>
          </div>
          <div className="flex gap-1">
            <div className="w-8 h-8 bg-red-500 rounded-full opacity-80"></div>
            <div className="w-8 h-8 bg-orange-500 rounded-full opacity-80 -ml-3"></div>
          </div>
        </div>

        {/* Accent Line */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-400 to-emerald-600 rounded-t-3xl"></div>
      </div>

      {/* Quick Stats */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
          <p className="text-slate-500 text-xs mb-1">This Month</p>
          <p className="text-slate-900">+$1,245.80</p>
          <div className="flex items-center gap-1 mt-1">
            <svg className="w-3 h-3 text-emerald-500" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
            </svg>
            <span className="text-emerald-600 text-xs">12.5%</span>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
          <p className="text-slate-500 text-xs mb-1">Spent Today</p>
          <p className="text-slate-900">$89.40</p>
          <div className="flex items-center gap-1 mt-1">
            <svg className="w-3 h-3 text-slate-400" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M14.707 10.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 12.586V5a1 1 0 012 0v7.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            <span className="text-slate-400 text-xs">3 transactions</span>
          </div>
        </div>
      </div>
    </div>
  );
}