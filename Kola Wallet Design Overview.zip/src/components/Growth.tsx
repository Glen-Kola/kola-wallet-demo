import { useState } from 'react';
import { Target, Users, Building2, Plus, TrendingUp } from 'lucide-react';
import { useKolaWallet } from '../hooks/useKolaWallet';

export function Growth() {
  const { savingsGoals, groups, organizations, loading } = useKolaWallet();
  const [activeSection, setActiveSection] = useState<'savings' | 'groups' | 'business'>('savings');

  return (
    <div className="p-6 space-y-6 pb-24">
      {/* Header */}
      <div>
        <h1 className="text-slate-900">Growth Hub</h1>
        <p className="text-slate-500 text-sm">Savings, Groups & Business</p>
      </div>

      {/* Section Tabs */}
      <div className="flex gap-2 bg-slate-100 rounded-2xl p-1">
        <button
          onClick={() => setActiveSection('savings')}
          className={`flex-1 py-2 px-4 rounded-xl text-sm transition-all ${
            activeSection === 'savings'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600'
          }`}
        >
          Savings
        </button>
        <button
          onClick={() => setActiveSection('groups')}
          className={`flex-1 py-2 px-4 rounded-xl text-sm transition-all ${
            activeSection === 'groups'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600'
          }`}
        >
          Groups
        </button>
        <button
          onClick={() => setActiveSection('business')}
          className={`flex-1 py-2 px-4 rounded-xl text-sm transition-all ${
            activeSection === 'business'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600'
          }`}
        >
          Business
        </button>
      </div>

      {/* Content */}
      {activeSection === 'savings' && <SavingsSection goals={savingsGoals} loading={loading} />}
      {activeSection === 'groups' && <GroupsSection groups={groups} loading={loading} />}
      {activeSection === 'business' && <BusinessSection organizations={organizations} loading={loading} />}
    </div>
  );
}

function SavingsSection({ goals, loading }: { goals: any[]; loading: boolean }) {
  const totalSavings = goals.reduce((sum, goal) => sum + goal.current, 0);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="bg-slate-200 rounded-3xl h-40 animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-slate-200 rounded-2xl h-24 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Total Savings */}
      <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-3xl p-6 text-white">
        <p className="text-emerald-100 text-sm mb-1">Total Savings</p>
        <h2 className="text-white mb-4">${totalSavings.toFixed(2)}</h2>
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4" />
          <span className="text-sm">Building your future</span>
        </div>
      </div>

      {/* Savings Goals */}
      <div className="flex justify-between items-center">
        <h3 className="text-slate-900">Your Goals</h3>
        <button className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
          <Plus className="w-5 h-5 text-emerald-600" />
        </button>
      </div>

      {goals.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <p className="text-slate-500">No savings goals yet</p>
          <button className="mt-4 text-emerald-600 text-sm">Create your first goal</button>
        </div>
      ) : (
        <div className="space-y-3">
          {goals.map((goal) => {
            const progress = (goal.current / goal.target) * 100;
            return (
              <div key={goal.id} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 bg-${goal.color}-100 rounded-xl flex items-center justify-center`}>
                      <Target className={`w-6 h-6 text-${goal.color}-600`} />
                    </div>
                    <div>
                      <p className="text-slate-900">{goal.name}</p>
                      <p className="text-slate-500 text-sm">${goal.current.toLocaleString()} of ${goal.target.toLocaleString()}</p>
                    </div>
                  </div>
                  <span className="text-slate-600 text-sm">{progress.toFixed(0)}%</span>
                </div>
                
                {/* Progress Bar */}
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div
                    className={`bg-${goal.color}-500 h-2 rounded-full transition-all`}
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function GroupsSection({ groups, loading }: { groups: any[]; loading: boolean }) {
  if (loading) {
    return (
      <div className="space-y-4">
        <div className="bg-slate-200 rounded-3xl h-40 animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-slate-200 rounded-2xl h-24 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Create Group CTA */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl p-6 text-white">
        <h3 className="text-white mb-2">Start a Savings Group</h3>
        <p className="text-blue-100 text-sm mb-4">Pool funds with friends and family</p>
        <button className="bg-white text-blue-600 px-6 py-2 rounded-xl text-sm hover:bg-blue-50 transition-colors">
          Create Group
        </button>
      </div>

      {/* Active Groups */}
      <h3 className="text-slate-900">Your Groups</h3>
      
      {groups.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <p className="text-slate-500">No active groups yet</p>
          <button className="mt-4 text-emerald-600 text-sm">Create your first group</button>
        </div>
      ) : (
        <div className="space-y-3">
          {groups.map((group) => (
            <div key={group.id} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-slate-900">{group.name}</p>
                    <p className="text-slate-500 text-sm">{group.members} members</p>
                  </div>
                </div>
                <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Active</span>
              </div>
              
              <div className="flex justify-between items-center pt-3 border-t border-slate-100">
                <div>
                  <p className="text-slate-500 text-xs">Pool Balance</p>
                  <p className="text-slate-900">${group.balance.toLocaleString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500 text-xs">Next Payout</p>
                  <p className="text-slate-900 text-sm">{group.nextPayout}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function BusinessSection({ organizations, loading }: { organizations: any[]; loading: boolean }) {
  if (loading) {
    return (
      <div className="space-y-4">
        <div className="bg-slate-200 rounded-3xl h-40 animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-slate-200 rounded-2xl h-24 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Business Overview */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-6 text-white">
        <p className="text-slate-400 text-sm mb-1">Business Account</p>
        <h2 className="text-white mb-4">$45,600.00</h2>
        <div className="flex gap-3">
          <button className="flex-1 bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm hover:bg-emerald-600 transition-colors">
            Run Payroll
          </button>
          <button className="flex-1 bg-slate-700 text-white px-4 py-2 rounded-xl text-sm hover:bg-slate-600 transition-colors">
            Bulk Pay
          </button>
        </div>
      </div>

      {/* Organizations */}
      <h3 className="text-slate-900">Your Organizations</h3>
      
      {organizations.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center">
          <p className="text-slate-500">No organizations yet</p>
          <button className="mt-4 text-emerald-600 text-sm">Add your first organization</button>
        </div>
      ) : (
        <div className="space-y-3">
          {organizations.map((org) => (
            <div key={org.id} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-slate-700" />
                  </div>
                  <div>
                    <p className="text-slate-900">{org.name}</p>
                    <p className="text-slate-500 text-sm">{org.role}</p>
                  </div>
                </div>
                <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full">{org.role}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-100">
                <div>
                  <p className="text-slate-500 text-xs">Balance</p>
                  <p className="text-slate-900">${org.balance.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-slate-500 text-xs">Employees</p>
                  <p className="text-slate-900">{org.employees}</p>
                </div>
              </div>

              {/* Pending Approvals */}
              <div className="mt-4 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <p className="text-slate-700 text-sm">3 pending approvals</p>
                  <button className="text-emerald-600 text-sm">Review</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Organization */}
      <button className="w-full bg-slate-100 rounded-2xl p-4 flex items-center justify-center gap-2 text-slate-700 hover:bg-slate-200 transition-colors">
        <Plus className="w-5 h-5" />
        <span>Add Organization</span>
      </button>
    </div>
  );
}