import { Fingerprint } from 'lucide-react';

interface BiometricLoginProps {
  onLogin: () => void;
}

export function BiometricLogin({ onLogin }: BiometricLoginProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] text-center space-y-8">
        {/* Logo */}
        <div className="space-y-2">
          <div className="w-20 h-20 bg-emerald-500 rounded-3xl mx-auto flex items-center justify-center shadow-2xl">
            <div className="w-12 h-12 border-4 border-white rounded-2xl"></div>
          </div>
          <h1 className="text-white">Kola Wallet</h1>
          <p className="text-slate-400 text-sm">Secure & Fast Transactions</p>
        </div>

        {/* Biometric Button */}
        <div className="space-y-4">
          <button
            onClick={onLogin}
            className="w-32 h-32 bg-white bg-opacity-10 backdrop-blur-lg rounded-full mx-auto flex items-center justify-center hover:bg-opacity-20 transition-all active:scale-95 shadow-2xl border border-white border-opacity-20"
          >
            <Fingerprint className="w-16 h-16 text-emerald-400" />
          </button>
          <p className="text-white">Tap to unlock</p>
          <p className="text-slate-400 text-sm">Use Face ID or Fingerprint</p>
        </div>

        {/* Alternative Login */}
        <button className="text-emerald-400 text-sm hover:text-emerald-300 transition-colors">
          Use PIN instead
        </button>

        {/* Footer */}
        <div className="pt-8">
          <p className="text-slate-500 text-xs">Protected by end-to-end encryption</p>
        </div>
      </div>
    </div>
  );
}
