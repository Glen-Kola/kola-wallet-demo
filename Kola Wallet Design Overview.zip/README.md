
  # Kola Wallet Design Overview

  This is a code bundle for Kola Wallet Design Overview. The original project is available at https://www.figma.com/design/wiP2nqtWWrZql4KYa6rjfk/Kola-Wallet-Design-Overview.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  